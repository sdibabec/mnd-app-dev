<?php
$conexion = mysql_connect("localhost","sdiba691_root","B@surto91");
mysql_select_db("sdiba691_cet");
?>
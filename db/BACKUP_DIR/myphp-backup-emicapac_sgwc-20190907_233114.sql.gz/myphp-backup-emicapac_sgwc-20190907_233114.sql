CREATE DATABASE IF NOT EXISTS `emicapac_sgwc`;

USE `emicapac_sgwc`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `BitCursos`;

CREATE TABLE `BitCursos` (
  `eCodCurso` int(11) NOT NULL AUTO_INCREMENT,
  `eCodEntidad` int(11) NOT NULL,
  `eCodUsuario` int(11) NOT NULL,
  `fhFecha` datetime NOT NULL,
  `eCodEstatus` int(11) DEFAULT NULL,
  `tTitulo` varchar(150) NOT NULL,
  `tObjetivo` text DEFAULT NULL,
  `tDescripcion` text DEFAULT NULL,
  `fhFechaCurso` datetime DEFAULT NULL,
  `eHoras` int(11) NOT NULL,
  `tUbicacion` text DEFAULT NULL,
  `tFlyer` varchar(250) DEFAULT NULL,
  `tSlider` varchar(250) DEFAULT NULL,
  `tPDF` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`eCodCurso`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `BitCursos` VALUES (4,1,1,"2019-08-28 17:42:41",3,"Curso de Prueba","Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed massa eros, accumsan non enim quis, feugiat finibus libero. Nulla ac justo velit. Donec commodo diam eget dui volutpat lobortis. Nam sed sapien dui. Quisque facilisis elit metus, quis dignissim quam commodo vitae. Mauris hendrerit sed urna sit amet mattis. Sed eget leo eget elit dignissim faucibus id sed odio. Donec at ante in sem malesuada scelerisque non et felis. Donec condimentum eget turpis id aliquet. Suspendisse sed diam rhoncus, placerat lacus a, porta eros. Nunc eros urna, pulvinar eget ornare sed, vulputate eu arcu.\r\n\r\nAenean ut erat in augue tempor interdum ut a dui. In ullamcorper posuere nisi, et aliquam mi feugiat eu. Quisque auctor, eros nec congue convallis, nisi velit luctus odio, eu eleifend leo augue non tellus. In nulla augue, vestibulum vel dignissim eget, maximus sit amet ipsum. Suspendisse quis mollis purus. Aliquam rhoncus finibus turpis vitae lobortis. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Phasellus lobortis feugiat quam, non convallis tellus euismod quis. Phasellus congue ipsum in gravida tincidunt.","Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed massa eros, accumsan non enim quis, feugiat finibus libero. Nulla ac justo velit. Donec commodo diam eget dui volutpat lobortis. Nam sed sapien dui. Quisque facilisis elit metus, quis dignissim quam commodo vitae. Mauris hendrerit sed urna sit amet mattis. Sed eget leo eget elit dignissim faucibus id sed odio. Donec at ante in sem malesuada scelerisque non et felis. Donec condimentum eget turpis id aliquet. Suspendisse sed diam rhoncus, placerat lacus a, porta eros. Nunc eros urna, pulvinar eget ornare sed, vulputate eu arcu.\r\n\r\nAenean ut erat in augue tempor interdum ut a dui. In ullamcorper posuere nisi, et aliquam mi feugiat eu. Quisque auctor, eros nec congue convallis, nisi velit luctus odio, eu eleifend leo augue non tellus. In nulla augue, vestibulum vel dignissim eget, maximus sit amet ipsum. Suspendisse quis mollis purus. Aliquam rhoncus finibus turpis vitae lobortis. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Phasellus lobortis feugiat quam, non convallis tellus euismod quis. Phasellus congue ipsum in gravida tincidunt.","2019-08-28 12:00:00",10,"Viaducto RÃ­o Becerra 168, San Pedro de los Pinos, 03800 Ciudad de MÃ©xico, CDMX","inv/5d45d205d6af4.jpg","inv/5d45d205d8d91.jpg",NULL);


DROP TABLE IF EXISTS `BitRegistrosCursos`;

CREATE TABLE `BitRegistrosCursos` (
  `eCodRegistro` int(11) NOT NULL AUTO_INCREMENT,
  `eCodUsuario` int(11) NOT NULL,
  `fhFechaRegistro` datetime DEFAULT NULL,
  `eCodCurso` int(11) NOT NULL,
  `eCodModalidad` int(11) NOT NULL,
  `eCodEstatus` int(11) NOT NULL,
  `eCodEstatusPago` int(11) NOT NULL DEFAULT 2,
  `eCodTipoPago` int(11) DEFAULT NULL,
  `dMonto` float DEFAULT NULL,
  `bRequiereIVA` int(11) DEFAULT NULL,
  PRIMARY KEY (`eCodRegistro`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `BitRegistrosCursos` VALUES (1,5,"2019-08-06 17:17:37",4,1,1,9,4,5,NULL);


DROP TABLE IF EXISTS `BitSolicitudesRentas`;

CREATE TABLE `BitSolicitudesRentas` (
  `eCodRenta` int(11) NOT NULL AUTO_INCREMENT,
  `eCodEntidad` int(11) NOT NULL,
  `fhFecha` datetime NOT NULL,
  `fhFechaRenta` datetime NOT NULL,
  `eCodMontaje` int(11) NOT NULL,
  `tNombre` varchar(250) NOT NULL,
  `tCorreo` varchar(100) NOT NULL,
  `tTelefono` varchar(15) NOT NULL,
  `eHoras` int(11) NOT NULL,
  `ePersonas` int(11) NOT NULL,
  `eCodDescanso` int(11) NOT NULL,
  PRIMARY KEY (`eCodRenta`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `BitTransacciones`;

CREATE TABLE `BitTransacciones` (
  `eCodTransaccion` int(11) NOT NULL AUTO_INCREMENT,
  `eCodUsuario` int(11) NOT NULL,
  `eCodEvento` int(11) NOT NULL,
  `fhFecha` datetime NOT NULL,
  `dMonto` double NOT NULL,
  `eCodTipoPago` int(11) NOT NULL,
  PRIMARY KEY (`eCodTransaccion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `CatBancos`;

CREATE TABLE `CatBancos` (
  `eCodBanco` int(11) NOT NULL AUTO_INCREMENT,
  `tCodEstatus` char(2) NOT NULL DEFAULT 'AC',
  `tNombre` varchar(100) DEFAULT NULL,
  `tBanco` varchar(25) NOT NULL,
  `tTarjeta` varchar(25) NOT NULL,
  `tCuenta` varchar(25) NOT NULL,
  `tCLABE` varchar(30) NOT NULL,
  PRIMARY KEY (`eCodBanco`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `CatBancos` VALUES (1,"AC","Mario Ernesto Basurto Medrano","BBVA","4152-3135-0812-9637",1527623504,012180015276235049);


DROP TABLE IF EXISTS `CatCategorias`;

CREATE TABLE `CatCategorias` (
  `eCodCategoria` int(11) NOT NULL AUTO_INCREMENT,
  `tNombre` varchar(50) NOT NULL,
  PRIMARY KEY (`eCodCategoria`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `CatCategorias` VALUES (1,"RmlzY2Fs"),
(2,"dGVzdA=="),
(3,"cHJ1ZWJhcw=="),
(4,"dmFsaWRhY2lvbg==");


DROP TABLE IF EXISTS `CatDescansos`;

CREATE TABLE `CatDescansos` (
  `eCodDescanso` int(11) NOT NULL AUTO_INCREMENT,
  `eCodEntidad` int(11) NOT NULL,
  `eCodEstatus` int(11) DEFAULT 3,
  `dPrecio` float DEFAULT NULL,
  `tNombre` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`eCodDescanso`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `CatDescansos` VALUES (1,3,3,400,"Reposteria solo en receso"),
(2,3,3,600,"Reposteria contínuo");


DROP TABLE IF EXISTS `CatEntidades`;

CREATE TABLE `CatEntidades` (
  `eCodEntidad` int(11) NOT NULL AUTO_INCREMENT,
  `eCodEstatus` int(11) DEFAULT 3,
  `tNombre` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`eCodEntidad`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `CatEntidades` VALUES (1,3,"SDI·BABEC");


DROP TABLE IF EXISTS `CatEstatus`;

CREATE TABLE `CatEstatus` (
  `eCodEstatus` int(11) NOT NULL AUTO_INCREMENT,
  `tCodEstatus` varchar(2) DEFAULT NULL,
  `tNombre` varchar(15) DEFAULT NULL,
  `tIcono` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`eCodEstatus`),
  UNIQUE KEY `tCodEstatus_UNIQUE` (`tCodEstatus`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

INSERT INTO `CatEstatus` VALUES (1,"NU","Nuevo","far fa-question-circle"),
(2,"PR","En proceso...","fas fa-cogs"),
(3,"AC","Activo","fa fa-check"),
(4,"CA","Cancelado","fas fa-ban"),
(5,"RE","Rechazado","fas fa-minus-circle"),
(6,"BL","Bloqueado","fas fa-lock"),
(7,"EL","Eliminado","far fa-trash-alt"),
(8,"FI","Finalizado","fas fa-check-double"),
(9,"PA","Pagado","fas fa-dollar-sign");


DROP TABLE IF EXISTS `CatModalidades`;

CREATE TABLE `CatModalidades` (
  `eCodModalidad` int(11) NOT NULL AUTO_INCREMENT,
  `tNombre` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`eCodModalidad`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `CatModalidades` VALUES (1,"Presencial"),
(2,"Online");


DROP TABLE IF EXISTS `CatMontajes`;

CREATE TABLE `CatMontajes` (
  `eCodMontaje` int(11) NOT NULL AUTO_INCREMENT,
  `eCodEntidad` int(11) NOT NULL,
  `eCodEstatus` int(11) DEFAULT 3,
  `tNombre` varchar(50) DEFAULT NULL,
  `tImagen` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`eCodMontaje`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `CatMontajes` VALUES (1,3,3,"Mesa de Planos",NULL),
(2,3,3,"Auditorio",NULL);


DROP TABLE IF EXISTS `CatServicios`;

CREATE TABLE `CatServicios` (
  `eCodServicio` int(11) NOT NULL AUTO_INCREMENT,
  `eCodEntidad` int(11) NOT NULL,
  `eCodEstatus` int(11) DEFAULT 3,
  `dPrecio` float DEFAULT NULL,
  `tNombre` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`eCodServicio`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `CatServicios` VALUES (1,3,3,120,"WiFi"),
(2,3,3,300,"Red Ethernet Dedicado");


DROP TABLE IF EXISTS `CatTiposPagos`;

CREATE TABLE `CatTiposPagos` (
  `eCodTipoPago` int(11) NOT NULL AUTO_INCREMENT,
  `tNombre` varchar(25) NOT NULL,
  PRIMARY KEY (`eCodTipoPago`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `CatTiposPagos` VALUES (1,"Efectivo"),
(2,"Tarjeta"),
(3,"Cheque"),
(4,"Transferencia");


DROP TABLE IF EXISTS `CatTiposSecciones`;

CREATE TABLE `CatTiposSecciones` (
  `eCodTipoSeccion` int(11) NOT NULL AUTO_INCREMENT,
  `tCodTipoSeccion` char(3) NOT NULL,
  `tNombre` varchar(50) NOT NULL,
  `tIcono` varchar(50) DEFAULT NULL,
  `ePosicion` int(11) NOT NULL,
  PRIMARY KEY (`eCodTipoSeccion`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `CatTiposSecciones` VALUES (1,"cat","Catalogo","fas fa-folder-open",2),
(2,"ser","Servicio","fas fa-list-alt",3),
(3,"sis","Sistema","fas fa-cogs",5),
(4,"con","Consultas","fas fa-search",4),
(5,"ini","Inicio","fas fa-tachometer-alt",1);


DROP TABLE IF EXISTS `RelCursosCategorias`;

CREATE TABLE `RelCursosCategorias` (
  `eCodCurso` int(11) NOT NULL,
  `eCodCategoria` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `RelCursosCategorias` VALUES (4,4),
(4,3),
(4,2),
(4,1);


DROP TABLE IF EXISTS `RelCursosModalidades`;

CREATE TABLE `RelCursosModalidades` (
  `eCodCurso` int(11) NOT NULL,
  `eCodModalidad` int(11) NOT NULL,
  `eLugares` int(11) NOT NULL,
  `dPrecio` float DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `RelCursosModalidades` VALUES (3,1,5,5),
(4,1,5,5);


DROP TABLE IF EXISTS `RelCursosModulos`;

CREATE TABLE `RelCursosModulos` (
  `eCodRegistro` int(11) NOT NULL AUTO_INCREMENT,
  `eCodCurso` int(11) NOT NULL,
  `eModulo` int(11) NOT NULL,
  `tNombre` varchar(150) DEFAULT NULL,
  `fhFechaModulo` datetime DEFAULT NULL,
  `eHoras` int(11) NOT NULL,
  `tEmbed` text DEFAULT NULL,
  PRIMARY KEY (`eCodRegistro`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `RelCursosModulos` VALUES (1,4,1,"Modulo 1","2019-08-28 12:00:00",5,"https://www.nasa.gov/nasalive/");


DROP TABLE IF EXISTS `RelRegistrosCursosModulos`;

CREATE TABLE `RelRegistrosCursosModulos` (
  `eCodRegistro` int(11) NOT NULL,
  `eCodModulo` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `RelRegistrosCursosModulos` VALUES (1,1),
(2,1);


DROP TABLE IF EXISTS `RelSolicitudesRentasServicios`;

CREATE TABLE `RelSolicitudesRentasServicios` (
  `eCodRenta` int(11) NOT NULL,
  `eCodServicio` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `SisBotones`;

CREATE TABLE `SisBotones` (
  `tCodBoton` varchar(2) NOT NULL,
  `tTitulo` varchar(20) DEFAULT NULL,
  `tFuncion` varchar(25) DEFAULT NULL,
  `tAccion` varchar(25) NOT NULL,
  `tIcono` varchar(45) DEFAULT NULL,
  `tId` varchar(15) NOT NULL,
  `tClase` varchar(50) NOT NULL,
  `tHTML` varchar(255) DEFAULT NULL,
  `bDeshabilitado` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`tCodBoton`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `SisBotones` VALUES ("CO","Listado","window.location=\'url\';","","<i class=\"fas fa-table\"></i>","","btn btn-primary",NULL,NULL),
("EL","Eliminar","eliminar();","","<i class=\"far fa-trash-alt\"></i>","","btn btn-danger",NULL,NULL),
("GU","Guardar","validar();","","<i class=\"fa fa-floppy-o\"></i>","btnGuardar","btn btn-primary",NULL,1),
("IM","Imprimir","imprimir();","","<i class=\"fas fa-print\"></i>","","btn btn-success",NULL,NULL),
("NU","Nuevo","window.location=\'url\';","","<i class=\"fa fa-plus\"></i>","btnNuevo","btn btn-primary",NULL,NULL),
("PD","Descargar PDF","window.location=\'url\';","generar/pdf","<i class=\"fas fa-file-pdf\"></i>","","btn btn-danger",NULL,NULL),
("RE","Rechazar","rechazar();","","<i class=\"far fa-trash-alt\"></i>","","btn btn-danger",NULL,NULL),
("SR","Consultar","consultarFecha();","","<i class=\"fas fa-search\"></i>","","btn btn-info","<form id=\"Datos\" method=\"post\" action=\"<?=$_SERVER[\'REQUEST_URI\']?>\"><input type=\"text\" id=\"datepicker\"><input type=\"hidden\" name=\"fhFechaConsulta\" id=\"datepicker1\"></form>",NULL),
("VA",NULL,"activarValidacion();","","<i class=\"fa fa-key\" ></i>","btnValidar","btn btn-primary","<input type=\"password\" class=\"form-control col-md-3\" onkeyup=\"validarUsuario()\"  id=\"tPasswordOperaciones\"  style=\"display:none;\" size=\"8\">",NULL),
("XL","Descargar XLS","window.location=\'url\';","exportar/xls","<i class=\"fas fa-file-excel\"></i>","","btn btn-success",NULL,NULL);


DROP TABLE IF EXISTS `SisLogs`;

CREATE TABLE `SisLogs` (
  `eCodEvento` int(11) NOT NULL AUTO_INCREMENT,
  `eCodUsuario` int(11) NOT NULL,
  `fhFecha` datetime NOT NULL,
  `tDescripcion` varchar(250) NOT NULL,
  PRIMARY KEY (`eCodEvento`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `SisLogs` VALUES (1,2,"2019-08-25 15:59:24","Se ha insertado/actualizado el curso 0000004"),
(2,2,"2019-08-28 17:20:54","Se ha insertado/actualizado la categoria 0000000"),
(3,2,"2019-08-28 17:42:02","Se ha insertado/actualizado el curso 0000004"),
(4,2,"2019-08-28 17:42:41","Se ha insertado/actualizado el curso 0000004");


DROP TABLE IF EXISTS `SisPerfiles`;

CREATE TABLE `SisPerfiles` (
  `eCodPerfil` int(11) NOT NULL AUTO_INCREMENT,
  `tNombre` varchar(15) DEFAULT NULL,
  `tCodEstatus` varchar(2) DEFAULT NULL,
  PRIMARY KEY (`eCodPerfil`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `SisPerfiles` VALUES (1,"Administrador","AC"),
(2,"Ventas","AC"),
(3,"Pagos","AC"),
(4,"Clientes","AC");


DROP TABLE IF EXISTS `SisSecciones`;

CREATE TABLE `SisSecciones` (
  `tCodSeccion` varchar(20) NOT NULL,
  `tCodPadre` varchar(20) DEFAULT NULL,
  `tCodTipoSeccion` char(3) DEFAULT NULL,
  `tDirectorio` varchar(5) DEFAULT NULL,
  `tTitulo` varchar(60) DEFAULT NULL,
  `eCodEstatus` int(11) DEFAULT NULL,
  `ePosicion` int(11) DEFAULT NULL,
  `bFiltro` int(11) NOT NULL,
  `bPublico` int(11) DEFAULT NULL,
  `tIcono` varchar(30) NOT NULL,
  PRIMARY KEY (`tCodSeccion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `SisSecciones` VALUES ("cata-cur-con","inicio","cat","cur","Cursos",3,1,0,NULL,"fa fa-file-text-o"),
("cata-cur-det","cata-cur-con",NULL,"cur","Detalles de Curso",3,3,0,NULL,"fa fa-file-text-o"),
("cata-cur-reg","cata-cur-con",NULL,"cur","+ Cursos",3,2,0,NULL,"fa fa-file-text-o"),
("cata-des-con","inicio","cat","ren","Coffee Break",3,7,0,NULL,"fa fa-file-text-o"),
("cata-des-reg","cata-des-con",NULL,"ren","+ Coffee Break",3,2,0,NULL,"fa fa-file-text-o"),
("cata-eti-con","inicio","cat","tag","Categorias",3,1,0,NULL,"fa fa-file-text-o"),
("cata-eti-reg","cata-eti-con",NULL,"tag","+ Categorias",3,2,0,NULL,"fa fa-file-text-o"),
("cata-mon-con","inicio","cat","ren","Montajes",3,8,0,NULL,"fa fa-file-text-o"),
("cata-mon-reg","cata-mon-con",NULL,"ren","+ Montajes",3,2,0,NULL,"fa fa-file-text-o"),
("cata-per-reg","cata-per-sis",NULL,"cof","+ Perfiles",3,2,0,NULL,"fa fa-file-text-o"),
("cata-per-sis","inicio","sis","cof","Perfiles",3,3,0,NULL,"fa fa-file-text-o"),
("cata-reg-con","inicio","con","reg","Inscripciones",3,2,0,NULL,"fas fa-list-alt"),
("cata-reg-det","cata-reg-con",NULL,"reg","Detalles del Registro",3,1,0,NULL,"fa fa-file-text-o"),
("cata-reg-pag","cata-reg-con",NULL,"reg","Confirmar Pago",3,2,0,NULL,"fa fa-file-text-o"),
("cata-ren-con","inicio","ser","ren","Rentas de Espacios",3,9,0,NULL,"fas fa-concierge-bell"),
("cata-ren-reg","cata-ren-con",NULL,"ren","+ Rentas",3,2,0,NULL,"fa fa-file-text-o"),
("cata-ser-con","inicio","cat","ren","Servicios",3,6,0,NULL,"fa fa-file-text-o"),
("cata-ser-reg","cata-ser-con",NULL,"ren","+ Servicios",3,2,0,NULL,"fa fa-file-text-o"),
("cata-usr-per","inicio","sis","cof","Mi Perfil",3,20,0,NULL,"fas fa-id-card"),
("cata-usr-reg","cata-usr-sis",NULL,"cof","+ Usuarios",3,1,0,NULL,"fa fa-file-text-o"),
("cata-usr-sis","inicio","sis","cof","Usuarios",3,4,0,NULL,"fa fa-file-text-o"),
("inicio",NULL,"ini","das","Dashboard",3,1,1,NULL,"fa fa-tachometer-alt"),
("sis-log-con","inicio","sis","sis","Logs de Sistema",3,5,0,NULL,"fa fa-file-text-o");


DROP TABLE IF EXISTS `SisSeccionesBotones`;

CREATE TABLE `SisSeccionesBotones` (
  `eCodRegistro` int(11) NOT NULL AUTO_INCREMENT,
  `tCodPadre` varchar(15) DEFAULT NULL,
  `tCodSeccion` varchar(15) DEFAULT NULL,
  `tCodBoton` varchar(2) DEFAULT NULL,
  `tFuncion` varchar(25) DEFAULT NULL,
  `tEtiqueta` varchar(30) DEFAULT NULL,
  `ePosicion` int(11) DEFAULT NULL,
  PRIMARY KEY (`eCodRegistro`),
  KEY `tCodPadre_rel_fk_botones_idx` (`tCodPadre`),
  KEY `tCodBoton_rel_fk_botones_idx` (`tCodBoton`),
  CONSTRAINT `tCodBoton_rel_fk_botones` FOREIGN KEY (`tCodBoton`) REFERENCES `SisBotones` (`tCodBoton`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tCodPadre_rel_fk_botones` FOREIGN KEY (`tCodPadre`) REFERENCES `SisSecciones` (`tCodSeccion`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8;

INSERT INTO `SisSeccionesBotones` VALUES (1,"cata-usr-sis","cata-usr-reg","NU",NULL,"Nuevo",1),
(2,"cata-per-reg","cata-per-reg","VA",NULL,NULL,1),
(3,"cata-per-reg","cata-per-reg","GU","guardar();",NULL,2),
(4,"cata-per-reg","cata-per-sis","CO",NULL,NULL,3),
(5,"cata-usr-reg","cata-usr-reg","VA",NULL,NULL,1),
(6,"cata-usr-reg","cata-usr-reg","GU",NULL,NULL,2),
(7,"cata-usr-reg","sis-usr-con","CO",NULL,NULL,3),
(8,"cata-cur-con","cata-cur-reg","NU",NULL,"Nuevo",1),
(9,"cata-cur-reg","cata-cur-reg","VA",NULL,NULL,1),
(10,"cata-cur-reg","cata-cur-reg","GU","guardar();",NULL,2),
(11,"cata-cur-reg","cata-cur-con","CO",NULL,NULL,3),
(12,"cata-per-sis","cata-per-reg","NU",NULL,"Nuevo",1),
(13,"cata-reg-pag","cata-reg-pag","VA",NULL,NULL,1),
(14,"cata-reg-pag","cata-reg-pag","GU","guardar();",NULL,2),
(15,"cata-reg-pag","cata-reg-pag","CO",NULL,NULL,3),
(16,"cata-reg-det","cata-reg-con","CO",NULL,NULL,1),
(17,"cata-cur-det","cata-cur-con","CO",NULL,NULL,1),
(18,"cata-ser-reg","cata-ser-reg","VA",NULL,NULL,1),
(19,"cata-ser-reg","cata-ser-reg","GU","guardar();",NULL,2),
(20,"cata-ser-reg","cata-ser-con","CO",NULL,NULL,3),
(21,"cata-des-reg","cata-des-reg","VA",NULL,NULL,1),
(22,"cata-des-reg","cata-des-reg","GU","guardar();",NULL,2),
(23,"cata-des-reg","cata-des-con","CO",NULL,NULL,3),
(24,"cata-mon-reg","cata-mon-reg","VA",NULL,NULL,1),
(25,"cata-mon-reg","cata-mon-reg","GU","guardar();",NULL,2),
(26,"cata-mon-reg","cata-mon-con","CO",NULL,NULL,3),
(27,"cata-ren-reg","cata-ren-reg","VA",NULL,NULL,1),
(28,"cata-ren-reg","cata-ren-reg","GU","guardar();",NULL,2),
(29,"cata-ren-reg","cata-ren-con","CO",NULL,NULL,3),
(32,"cata-ren-con","cata-ren-reg","NU",NULL,"Nuevo",1),
(33,"cata-ser-con","cata-ser-reg","NU",NULL,"Nuevo",1),
(34,"cata-des-con","cata-des-reg","NU",NULL,"Nuevo",1),
(35,"cata-mon-con","cata-mon-reg","NU",NULL,"Nuevo",1),
(36,"cata-ren-reg","cata-ren-con","CO",NULL,NULL,3),
(37,"cata-ren-reg","cata-ren-reg","VA",NULL,NULL,1),
(38,"cata-ren-reg","cata-ren-reg","GU","guardar();",NULL,2),
(39,"cata-usr-per","cata-usr-per","VA",NULL,NULL,1),
(40,"cata-usr-per","cata-usr-per","GU","guardar();",NULL,2),
(41,"cata-eti-con","cata-eti-reg","NU",NULL,"Nuevo",1),
(42,"cata-cur-det","cata-eti-con","CO",NULL,NULL,1),
(43,"cata-eti-reg","cata-eti-reg","VA",NULL,NULL,1),
(44,"cata-eti-reg","cata-eti-reg","GU","guardar();",NULL,2),
(45,"cata-eti-reg","cata-eti-con","CO",NULL,NULL,3);


DROP TABLE IF EXISTS `SisSeccionesMenusEmergentes`;

CREATE TABLE `SisSeccionesMenusEmergentes` (
  `eCodMenuEmergente` int(11) NOT NULL AUTO_INCREMENT,
  `tCodPadre` varchar(20) DEFAULT NULL,
  `tCodSeccion` varchar(20) DEFAULT NULL,
  `tCodPermiso` char(1) NOT NULL,
  `tTitulo` varchar(30) NOT NULL,
  `tAccion` varchar(25) DEFAULT NULL,
  `tFuncion` varchar(50) DEFAULT NULL,
  `tValor` varchar(20) DEFAULT NULL,
  `ePosicion` int(11) NOT NULL,
  PRIMARY KEY (`eCodMenuEmergente`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

INSERT INTO `SisSeccionesMenusEmergentes` VALUES (1,"cata-usr-sis","cata-usr-reg","A","Editar","editar","window.location=\'url\';","editar",1),
(2,"cata-per-sis","cata-per-reg","A","Editar","editar","window.location=\'url\';","editar",1),
(3,"cata-pro-con","cata-pro-reg","A","Editar","editar","window.location=\'url\';","editar",1),
(4,"cata-reg-con","cata-reg-det","A","Detalles","detalles","window.location=\'url\';","detalles",1),
(5,"inicio","cata-cur-det","A","Detalles Curso","detalles","window.location=\'url\';","detalles",2),
(6,"cata-cur-con","cata-cur-reg","A","Editar","editar","window.location=\'url\';","editar",1),
(7,"cata-cur-con","cata-cur-det","A","Detalles","detalles","window.location=\'url\';","detalles",1),
(8,"inicio","cata-reg-det","A","Detalles Registro","detalles","window.location=\'url\';","detalles",3),
(10,"inicio","cata-reg-pag","A","Confirmar Pago","confirmar-pago","window.location=\'url\';","confirmar-pago",1),
(11,"cata-reg-con","cata-reg-pag","A","Confirmar Pago","confirmar-pago","window.location=\'url\';","confirmar-pago",2),
(12,"cata-cur-con","cata-reg-con","A","Registros","detalles","window.location=\'url\';","detalles",3),
(13,"cata-ren-con","cata-ren-reg","A","Editar","editar","window.location=\'url\';","editar",1),
(14,"cata-ser-con","cata-ser-reg","A","Editar","editar","window.location=\'url\';","editar",1),
(15,"cata-mon-con","cata-mon-reg","A","Editar","editar","window.location=\'url\';","editar",1),
(16,"cata-des-con","cata-res-reg","A","Editar","editar","window.location=\'url\';","editar",1),
(17,"cata-eti-con","cata-eti-reg","A","Editar","editar","window.location=\'url\';","editar",1);


DROP TABLE IF EXISTS `SisSeccionesPerfiles`;

CREATE TABLE `SisSeccionesPerfiles` (
  `eCodPerfil` int(11) DEFAULT NULL,
  `tCodSeccion` varchar(15) DEFAULT NULL,
  `bAll` int(11) DEFAULT NULL,
  `bDelete` int(11) DEFAULT NULL,
  KEY `perfil_rel_seccion_fk_idx` (`eCodPerfil`),
  KEY `seccion_rel_perfil_idx` (`tCodSeccion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `SisSeccionesPerfiles` VALUES (4,"inicio",0,0),
(4,"cata-reg-con",1,0),
(4,"cata-reg-det",1,0),
(4,"cata-usr-per",0,0),
(3,"inicio",0,0),
(3,"cata-cur-con",0,0),
(3,"cata-cur-det",0,0),
(3,"cata-reg-con",0,0),
(3,"cata-reg-det",0,0),
(3,"cata-reg-pag",0,0),
(3,"cata-usr-per",0,0),
(2,"inicio",0,0),
(2,"cata-cur-con",0,0),
(2,"cata-cur-reg",0,0),
(2,"cata-cur-det",0,0),
(2,"cata-reg-con",0,0),
(2,"cata-reg-det",0,0),
(2,"cata-ren-con",0,0),
(2,"cata-ren-reg",0,0),
(2,"cata-usr-per",0,0),
(1,"inicio",0,0),
(1,"cata-cur-con",0,0),
(1,"cata-cur-reg",0,0),
(1,"cata-cur-det",0,0),
(1,"cata-reg-con",0,0),
(1,"cata-reg-det",0,0),
(1,"cata-reg-pag",0,0),
(1,"cata-ser-con",0,0),
(1,"cata-ser-reg",0,0),
(1,"cata-des-con",0,0),
(1,"cata-des-reg",0,0),
(1,"cata-mon-con",0,0),
(1,"cata-mon-reg",0,0),
(1,"cata-ren-con",0,0),
(1,"cata-ren-reg",0,0),
(1,"cata-usr-per",0,0);


DROP TABLE IF EXISTS `SisSeccionesPerfilesInicio`;

CREATE TABLE `SisSeccionesPerfilesInicio` (
  `eCodPerfil` int(11) NOT NULL,
  `tCodSeccion` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `SisSeccionesPerfilesInicio` VALUES (1,"inicio"),
(4,"inicio"),
(2,"inicio"),
(3,"inicio");


DROP TABLE IF EXISTS `SisSeccionesReemplazos`;

CREATE TABLE `SisSeccionesReemplazos` (
  `eCodReemplazo` int(11) NOT NULL AUTO_INCREMENT,
  `tBase` varchar(4) NOT NULL,
  `tNombre` varchar(25) NOT NULL,
  PRIMARY KEY (`eCodReemplazo`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;

INSERT INTO `SisSeccionesReemplazos` VALUES (1,"cata","catalogo"),
(2,"oper","operaciones"),
(3,"reg","registro"),
(4,"inv","inventario"),
(5,"usr","usuario"),
(6,"sis","sistema"),
(7,"bod","bodega"),
(8,"ser","servicios"),
(9,"per","perfil"),
(10,"con","consultar"),
(11,"dash","dashboard"),
(12,"eve","eventos"),
(13,"noti","notificaciones"),
(14,"det","detalles"),
(15,"del","eliminar"),
(16,"log","logs"),
(17,"tra","transacciones"),
(18,"cit","citas"),
(19,"gen","generar"),
(20,"xls","excel"),
(21,"pdf","pdf"),
(22,"ren","rentas"),
(23,"cli","clientes"),
(24,"reg","editar"),
(25,"xls","xls"),
(26,"cot","crear"),
(27,"cot","editar-cotizacion"),
(28,"pro","productos"),
(29,"ped","pedidos"),
(30,"cur","cursos"),
(31,"pag","pago"),
(32,"des","descansos"),
(33,"mon","montajes"),
(34,"eti","etiquetas");


DROP TABLE IF EXISTS `SisUsuarios`;

CREATE TABLE `SisUsuarios` (
  `eCodUsuario` int(11) NOT NULL AUTO_INCREMENT,
  `eCodEntidad` int(11) DEFAULT NULL,
  `tTitulo` varchar(25) DEFAULT NULL,
  `tNombre` varchar(50) DEFAULT NULL,
  `tApellidos` varchar(50) DEFAULT NULL,
  `tCorreo` varchar(100) DEFAULT NULL,
  `tTelefonoFijo` varchar(15) DEFAULT NULL,
  `tTelefonoMovil` varchar(15) DEFAULT NULL,
  `tEstado` varchar(30) DEFAULT NULL,
  `tPasswordAcceso` varchar(60) DEFAULT NULL,
  `tPasswordOperaciones` varchar(60) DEFAULT NULL,
  `fhFechaCreacion` datetime DEFAULT NULL,
  `eCodEstatus` int(11) DEFAULT NULL,
  `eCodPerfil` int(11) DEFAULT NULL,
  `bAll` int(11) DEFAULT NULL,
  `tRFC` varchar(20) DEFAULT NULL,
  `tRazonSocial` varchar(200) DEFAULT NULL,
  `tDomicilioFiscal` text DEFAULT NULL,
  PRIMARY KEY (`eCodUsuario`),
  KEY `SisUsuarios_rel_perfiles_fk_idx` (`eCodPerfil`),
  KEY `CatEstatus_rel_usuarios_fk_idx` (`eCodEstatus`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

INSERT INTO `SisUsuarios` VALUES (1,1,"Ing.","Mario Ernesto","Basurto Medrano","babec.soluciones@gmail.com",NULL,NULL,NULL,"MjgwMjkx","MjgwMjkx","2018-07-29 00:00:00",3,1,1,NULL,NULL,NULL),
(2,1,NULL,"Coordinador","Prueba","coordinador@sdibabec.com",5555555555,5555555555,"CDMX","Y29vcmRpbmFkb3I=","Y29vcmRpbmFkb3I=","2019-08-28 15:01:15",3,1,0,NULL,NULL,NULL),
(3,1,NULL,"Ventas","Prueba","ventas@sdibabec.com",5555555555,5555555555,"CDMX","dmVudGFz","dmVudGFz","2019-08-28 15:01:48",3,2,0,NULL,NULL,NULL),
(4,1,NULL,"Pagos","Prueba","pagos@sdibabec.com",5555555555,5555555555,"CDMX","cGFnb3M=","cGFnb3M=","2019-08-28 15:02:19",3,3,0,NULL,NULL,NULL),
(5,1,NULL,"Cliente","Prueba","cliente@sdibabec.com",5555555555,5555555555,"CDMX","Y2xpZW50ZQ==","Y2xpZW50ZQ==","2019-08-28 18:03:30",3,4,0,NULL,NULL,NULL);


DROP TABLE IF EXISTS `SisVariables`;

CREATE TABLE `SisVariables` (
  `eCodVariable` int(11) NOT NULL AUTO_INCREMENT,
  `tNombre` varchar(50) NOT NULL,
  `tValor` varchar(255) NOT NULL,
  PRIMARY KEY (`eCodVariable`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `SisVariables` VALUES (1,"tURL","http://gwc.sdibabec.com/");


DROP TABLE IF EXISTS `payments`;

CREATE TABLE `payments` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `txnid` varchar(20) NOT NULL,
  `payment_amount` decimal(7,2) NOT NULL,
  `payment_status` varchar(25) NOT NULL,
  `itemid` varchar(25) NOT NULL,
  `createdtime` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



SET foreign_key_checks = 1;
